import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pagina-sem-autorizacao',
  templateUrl: './pagina-sem-autorizacao.component.html',
  styleUrls: ['./pagina-sem-autorizacao.component.scss']
})
export class PaginaSemAutorizacaoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
