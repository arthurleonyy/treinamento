export class ValidationMessages {

  /**
   * Mensagens de validação
   */
  static msg() {
    return {
      field: {
        required: 'Compo obrigatório.'
      },
    };
  }

}
