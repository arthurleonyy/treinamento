export const environment = {
  production: true,
  apiUrl: '%URL_API%'
};
