import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-operacoes',
  templateUrl: './operacoes.component.html',
  styleUrls: ['./operacoes.component.scss']
})
export class OperacoesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
